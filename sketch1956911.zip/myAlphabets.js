//D
function myAlphabetD() {
    push();
     push();
	   fill(231, 56, 32, 10)
	   arc(0, 0, 120, 80, 270, 90, CHORD);
     fill(0, 106, 182, 40)
	   arc(0, 0, 60, 40, 270, 90, CHORD);
     pop();
    pop();
}


//R
function myAlphabetR() {
	 fill(0, 106, 182, 80)
	 arc(0, 10, 120, 50, 270, 90, CHORD);
	 fill(251, 199, 13, 40)
	 triangle(0, 0, 0, 70, 60, 70); 
}

//A
function myAlphabetA() {
	 fill(0, 106, 182)
	 stroke(231, 56, 32, 10)
	 strokeWeight(15)
	 triangle(30, 75, 58, 20, 86, 75);
}

//W
function myAlphabetW() {
		 fill(251, 199, 13)
	 triangle(0, 0, 40, 0, 20, 70);
	 triangle(40, 0, 80, 0, 60, 70);
}